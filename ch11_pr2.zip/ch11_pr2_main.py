"""
This program uses a class and its subclass to have the user type in information about his work and will display that
information back to the user.
"""

import ch11_pr2_classes


def main():
    name = input('Enter your name: ')
    number = input('Enter your employee number: ')
    shift = int(input('Enter the number of your shift: '))
    rate = input('Enter your hourly rate: ')

    worker_one = ch11_pr2_classes.ProductionWorker(name, number, shift, rate)

    print(f'{worker_one.get_name()}, employee number {worker_one.get_number()}, worked on shift '
          f'{worker_one.get_shift()} earning ${worker_one.get_rate()} per hour.')


if __name__ == '__main__':
    main()
