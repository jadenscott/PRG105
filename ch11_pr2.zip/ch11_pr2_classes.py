"""
This file is where the parent class, Employee, and the subclass, ProductionWorker, are written.
"""


class Employee:
    def __init__(self, name, number):
        self.__name = name
        self.__number = number

    def set_name(self, name):
        self.__name = name

    def get_name(self):
        return self.__name

    def set_number(self, number):
        self.__number = number

    def get_number(self):
        return self.__number


class ProductionWorker(Employee):
    def __init__(self, name, number, shift, rate):
        Employee.__init__(self, name, number)
        self.__shift = shift
        self.__rate = rate

    def set_shift(self, shift):
        self.__shift = shift

    def get_shift(self):
        return self.__shift

    def set_rate(self, rate):
        self.__rate = rate

    def get_rate(self):
        return self.__rate
