"""
This program uses a parent class, OfficeFurniture, and its child class, Desk, to create objects out of both classes
"""

import ch11_pr1_parent_class
import ch11_pr1_desk_class


def main():
    my_chair = ch11_pr1_parent_class.OfficeFurniture('chair', 'mesh', 24, 24, 75)
    my_desk = ch11_pr1_desk_class.Desk('wood', 36, 24, 100, 'right', 2)

    print(f'My first piece of office furniture is a {my_chair.get_material()} {my_chair.get_category()} '
          f'width a length of {my_chair.get_length()} inches and a width of {my_chair.get_width()} inches. '
          f'The price of my chair is ${my_chair.get_price()}.')

    print(f'My desk is made out of {my_desk.get_material()} and is {my_desk.get_length()} inches long and '
          f'{my_desk.get_width()} inches wide. It costed ${my_desk.get_price()} has {my_desk.get_number_of_drawers()} '
          f'drawers on the {my_desk.get_location_of_drawers()} hand side')


if __name__ == '__main__':
    main()
