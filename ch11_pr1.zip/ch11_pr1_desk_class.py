"""
This file is where the child class of OfficeFurniture, Desk, is defined.
"""

import ch11_pr1_parent_class


class Desk(ch11_pr1_parent_class.OfficeFurniture):
    def __init__(self, material, length, width, price, location_of_drawers, number_of_drawers):
        ch11_pr1_parent_class.OfficeFurniture.__init__('desk', material, length, width, price)
        self.__location_of_drawers = location_of_drawers
        self.__number_of_drawers = number_of_drawers

    def set_location_of_drawers(self, location_of_drawers):
        self.__location_of_drawers = location_of_drawers

    def get_location_of_drawers(self):
        return self.__location_of_drawers

    def set_number_of_drawers(self, number_of_drawers):
        self.__number_of_drawers = number_of_drawers

    def get_number_of_drawers(self):
        return self.__number_of_drawers

    def __str__(self):
        print(f'The location of the drawers is {self.__location_of_drawers} and the number of drawers is '
              f'{self.__number_of_drawers}.')
