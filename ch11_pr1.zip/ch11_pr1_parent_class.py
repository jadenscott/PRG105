"""
This file is where the OfficeFurniture parent class will be defined.
"""


class OfficeFurniture:
    def __init__(self, category, material, length, width, price):
        self.__category = category
        self.__material = material
        self.__length = length
        self.__width = width
        self.__price = price

    def set_category(self, category):
        self.__category = category

    def get_category(self):
        return self.__category

    def set_material(self, material):
        self.__material = material

    def get_material(self):
        return self.__material

    def set_length(self, length):
        self.__length = length

    def get_length(self):
        return self.__length

    def set_width(self, width):
        self.__width = width

    def get_width(self):
        return self.__width

    def set_price(self, price):
        self.__price = price

    def get_price(self):
        return self.__price

    def __str__(self):
        print(f'The object is made out of {self.__material}.')
