"""
This program uses a parent class, OfficeFurniture, and its child class, Desk, to create objects out of both classes
"""

import ch11_pr1_parent_class
import ch11_pr1_desk_class


def main():
    my_chair = ch11_pr1_parent_class.OfficeFurniture('chair', 'mesh', 24, 24, 75)
    my_desk = ch11_pr1_desk_class.Desk('wood', 36, 24, 100, 'right', 2)

    print(my_chair)
    print(my_desk)


if __name__ == '__main__':
    main()
