"""
This file is where the OfficeFurniture parent class will be defined.
"""


class OfficeFurniture:
    def __init__(self, category, material, length, width, price):
        self.__category = category
        self.__material = material
        self.__length = length
        self.__width = width
        self.__price = price

    def set_category(self, category):
        self.__category = category

    def get_category(self):
        return self.__category

    def set_material(self, material):
        self.__material = material

    def get_material(self):
        return self.__material

    def set_length(self, length):
        self.__length = length

    def get_length(self):
        return self.__length

    def set_width(self, width):
        self.__width = width

    def get_width(self):
        return self.__width

    def set_price(self, price):
        self.__price = price

    def get_price(self):
        return self.__price

    def __str__(self):
        return (f'My first piece of office furniture is a {self.__material} {self.__category} '
          f'with a length of {self.__length} inches and a width of {self.__width} inches. '
          f'The price of my chair is ${self.__price}.')
