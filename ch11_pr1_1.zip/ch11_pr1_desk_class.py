"""
This file is where the child class of OfficeFurniture, Desk, is defined.
"""

import ch11_pr1_parent_class


class Desk(ch11_pr1_parent_class.OfficeFurniture):
    def __init__(self, material, length, width, price, location_of_drawers, number_of_drawers):
        ch11_pr1_parent_class.OfficeFurniture.__init__(self, 'desk', material, length, width, price)
        self.__location_of_drawers = location_of_drawers
        self.__number_of_drawers = number_of_drawers

    def set_location_of_drawers(self, location_of_drawers):
        self.__location_of_drawers = location_of_drawers

    def get_location_of_drawers(self):
        return self.__location_of_drawers

    def set_number_of_drawers(self, number_of_drawers):
        self.__number_of_drawers = number_of_drawers

    def get_number_of_drawers(self):
        return self.__number_of_drawers

    def __str__(self):
        return (f'My desk is made out of {self.get_material()} and is {self.get_length()} inches long and '
          f'{self.get_width()} inches wide. It costed ${self.get_price()} has {self.__number_of_drawers} '
          f'drawers on the {self.__location_of_drawers} hand side')
